package com.example.maze2;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class MazeView extends View {

    private Paint wallPaint;
    private Cell[][] cells;
    private int size;
    private Cell playerCell; // Track player's cell

    public MazeView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MazeView(Context context, int size, Cell[][] cells, Cell playerCell) {
        super(context);
        this.size = size;
        this.cells = cells;
        this.playerCell = playerCell;
        init();
    }



    private void init() {
        wallPaint = new Paint();
        wallPaint.setColor(Color.BLACK);
        wallPaint.setStrokeWidth(4);
    }

    // Method to update playerCell in MazeView
    public void updatePlayerCell(Cell newPlayerCell) {
        playerCell = newPlayerCell;
        invalidate(); // Trigger redraw
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        int cellSize = Math.min(width, height) / size;

        Paint playerPaint = new Paint();
        playerPaint.setColor(Color.RED);

        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                Cell cell = cells[row][col];

                int x = col * cellSize;
                int y = row * cellSize;

                if (cell.topWall) {
                    canvas.drawLine(x, y, x + cellSize, y, wallPaint);
                }
                if (cell.leftWall) {
                    canvas.drawLine(x, y, x, y + cellSize, wallPaint);
                }
                if (cell.bottomWall) {
                    canvas.drawLine(x, y + cellSize, x + cellSize, y + cellSize, wallPaint);
                }
                if (cell.rightWall) {
                    canvas.drawLine(x + cellSize, y, x + cellSize, y + cellSize, wallPaint);
                }
            }
        }
        // Red paint
        Paint redPaint = new Paint();
        redPaint.setColor(Color.RED);


        // Draw player's position
        if (playerCell != null) {
            int x = playerCell.getCol() * cellSize;
            int y = playerCell.getRow() * cellSize;
            canvas.drawRect(x, y, x + cellSize, y + cellSize, playerPaint);
        }

        // Draw blue square at coordinate (size - 1, size - 1)
        Paint bluePaint = new Paint();
        bluePaint.setColor(Color.BLUE);
        int x1 = (size-1) * cellSize;
        int y1 = (size-1) * cellSize;
        canvas.drawRect(x1, y1, x1 + cellSize, y1 + cellSize, bluePaint);
    }
}
