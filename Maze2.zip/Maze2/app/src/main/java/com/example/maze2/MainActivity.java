package com.example.maze2;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.widget.Chronometer;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final int SIZE = 20; // Size of the maze
    private Cell[][] cells;
    private List<Cell> unvisitedCells;
    private List<Cell> visitedCells;
    private Random random = new Random();
    private MazeView mazeView;
    private Cell playerCell; // Track player's cell

    private SensorManager sensorManager;
    private Sensor accelerometerSensor;

    private Chronometer chronometer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize and start Chronometer
        chronometer = new Chronometer(this);
        chronometer.setBase(SystemClock.elapsedRealtime());
        chronometer.start();

        // Generate the grid
        generateGrid(SIZE);

        // Initialize the lists
        unvisitedCells = new ArrayList<>();
        visitedCells = new ArrayList<>();

        // Add all cells to the unvisited list initially
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                unvisitedCells.add(cells[row][col]);
            }
        }

        // Start the maze generation algorithm
        generateMaze();

        // Set player's initial position to the top-left corner (0, 0)
        playerCell = cells[0][0];
        playerCell.setPlayer(true); // Set player on this cell

        // Get the MazeView and pass the maze data to it
        mazeView = findViewById(R.id.mazeView);
        mazeView = new MazeView(this, SIZE, cells, playerCell);
        setContentView(mazeView);

        // Initialize SensorManager and accelerometerSensor
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Register SensorEventListener for accelerometer
        if (accelerometerSensor != null) {
            sensorManager.registerListener(this, accelerometerSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister SensorEventListener to save battery
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float xAcc = event.values[0];
            float yAcc = event.values[1];

            // Update player movement based on accelerometer data
            updatePlayerPosition(xAcc, yAcc);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Handle accuracy changes
    }

    private void generateGrid(int size) {
        cells = new Cell[size][size];
        int id = 0;
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                cells[row][col] = new Cell(id++, row, col);
            }
        }
        findAndSetNeighbors();
    }

    private int getCellId(int row, int col) {
        if (row >= 0 && row < SIZE && col >= 0 && col < SIZE) {
            return cells[row][col].getId();
        } else {
            throw new IllegalArgumentException("Invalid row or column");
        }
    }

    private void findAndSetNeighbors() {
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                Cell cell = cells[row][col];
                if (row > 0) cell.addNeighbour(cells[row - 1][col]); // Top neighbor
                if (col < SIZE - 1) cell.addNeighbour(cells[row][col + 1]); // Right neighbor
                if (row < SIZE - 1) cell.addNeighbour(cells[row + 1][col]); // Bottom neighbor
                if (col > 0) cell.addNeighbour(cells[row][col - 1]); // Left neighbor
            }
        }
    }

    private void generateMaze() {
        Cell startCell = cells[0][0];
        unvisitedCells.remove(startCell);
        visitedCells.add(startCell);

        // DFS Stack for visiting cells
        List<Cell> stack = new ArrayList<>();
        stack.add(startCell);

        while (!stack.isEmpty()) {
            Cell currentCell = stack.get(stack.size() - 1);
            List<Cell> unvisitedNeighbors = new ArrayList<>();

            for (Cell neighbor : currentCell.getNeighbours()) {
                if (unvisitedCells.contains(neighbor)) {
                    unvisitedNeighbors.add(neighbor);
                }
            }

            if (!unvisitedNeighbors.isEmpty()) {
                Cell nextCell = unvisitedNeighbors.get(random.nextInt(unvisitedNeighbors.size()));
                removeWallBetweenCells(currentCell, nextCell);
                stack.add(nextCell);
                visitedCells.add(nextCell);
                unvisitedCells.remove(nextCell);
            } else {
                stack.remove(stack.size() - 1);
            }
        }
    }

    private void removeWallBetweenCells(Cell cell1, Cell cell2) {
        if (cell1.getRow() == cell2.getRow()) {
            if (cell1.getCol() < cell2.getCol()) {
                cell1.rightWall = false;
                cell2.leftWall = false;
            } else {
                cell1.leftWall = false;
                cell2.rightWall = false;
            }
        } else if (cell1.getCol() == cell2.getCol()) {
            if (cell1.getRow() < cell2.getRow()) {
                cell1.bottomWall = false;
                cell2.topWall = false;
            } else {
                cell1.topWall = false;
                cell2.bottomWall = false;
            }
        }
    }

    // Method to update player position based on accelerometer data
    private void updatePlayerPosition(float xAcc, float yAcc) {
        // Adjust player movement based on accelerometer readings
        if (Math.abs(xAcc) > Math.abs(yAcc)) {
            if (xAcc > 2.0f) {
                moveLeft();
            } else if (xAcc < -2.0f) {
                moveRight();
            }
        } else {
            if (yAcc > 2.0f) {
                moveDown();
            } else if (yAcc < -2.0f) {
                moveUp();
            }
        }
    }

    // Movement methods
    // Method to move the player up
    private void moveUp() {
        if (playerCell.getRow() > 0 && !playerCell.topWall) {
            playerCell = cells[playerCell.getRow() - 1][playerCell.getCol()];
            mazeView.updatePlayerCell(playerCell); // Update MazeView with new playerCell
            checkWinCondition();
        }
    }

    // Method to move the player down
    private void moveDown() {
        if (playerCell.getRow() < SIZE - 1 && !playerCell.bottomWall) {
            playerCell = cells[playerCell.getRow() + 1][playerCell.getCol()];
            mazeView.updatePlayerCell(playerCell); // Update MazeView with new playerCell
            checkWinCondition();
        }
    }

    // Method to move the player left
    private void moveLeft() {
        if (playerCell.getCol() > 0 && !playerCell.leftWall) {
            playerCell = cells[playerCell.getRow()][playerCell.getCol() - 1];
            mazeView.updatePlayerCell(playerCell); // Update MazeView with new playerCell
            checkWinCondition();
        }
    }

    // Method to move the player right
    private void moveRight() {
        if (playerCell.getCol() < SIZE - 1 && !playerCell.rightWall) {
            playerCell = cells[playerCell.getRow()][playerCell.getCol() + 1];
            mazeView.updatePlayerCell(playerCell); // Update MazeView with new playerCell
            checkWinCondition();
        }
    }

    // Method to check if the player has reached the winning cell
    private void checkWinCondition() {
        if (playerCell.getRow() == SIZE - 1 && playerCell.getCol() == SIZE - 1) {
            chronometer.stop(); // Stop the chronometer
            long elapsedMillis = SystemClock.elapsedRealtime() - chronometer.getBase();
            Intent intent = new Intent(MainActivity.this, WinActivity.class);
            intent.putExtra("elapsedTime", elapsedMillis);
            startActivity(intent);
            finish();
        }
    }
}
