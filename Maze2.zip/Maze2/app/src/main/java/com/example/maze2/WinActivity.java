package com.example.maze2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class WinActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_win);

        TextView winTextView = findViewById(R.id.winTextView);
        Button backButton = findViewById(R.id.backButton);

        // Retrieve elapsed time from the intent
        Intent intent = getIntent();
        long elapsedTime = intent.getLongExtra("elapsedTime", 0);

        // Format elapsed time to minutes and seconds
        int seconds = (int) (elapsedTime / 1000) % 60;
        int minutes = (int) ((elapsedTime / (1000 * 60)) % 60);
        String elapsedTimeString = String.format("You win! Time: %02d:%02d", minutes, seconds);

        // Set the win message
        winTextView.setText(elapsedTimeString);

        // Set up the back button to return to the main menu
        backButton.setOnClickListener(v -> {
            Intent backIntent = new Intent(WinActivity.this, MainMenuActivity.class);
            startActivity(backIntent);
            finish();
        });
    }
}
