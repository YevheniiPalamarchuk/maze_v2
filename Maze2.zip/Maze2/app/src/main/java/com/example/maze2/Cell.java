package com.example.maze2;

import java.util.ArrayList;
import java.util.List;

public class Cell {
    int id;
    int row, col; // Row and column in the grid
    boolean topWall = true;
    boolean bottomWall = true;
    boolean leftWall = true;
    boolean rightWall = true;
    boolean visited = false;
    private boolean isPlayer = false; // Flag to indicate if this cell is the player's position


    List<Cell> neighbours; // Neighbours of the cell
    List<Cell> passes; // Passes (neighbours that can be traveled to)

    public Cell(int id, int row, int col) {
        this.id = id;
        this.row = row;
        this.col = col;
        this.neighbours = new ArrayList<>();
        this.passes = new ArrayList<>();
    }

    // Add a neighbour to the list
    public void addNeighbour(Cell neighbour) {
        this.neighbours.add(neighbour);
    }

    // Add a pass to the list
    public void addPass(Cell pass) {
        this.passes.add(pass);
    }

    // Getters for the fields if needed
    public int getId() {
        return id;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public List<Cell> getNeighbours() {
        return neighbours;
    }

    public List<Cell> getPasses() {
        return passes;
    }

    // Method to set whether this cell is the player's position
    public void setPlayer(boolean isPlayer) {
        this.isPlayer = isPlayer;
    }

    // Method to check if this cell is the player's position
    public boolean isPlayer() {
        return isPlayer;
    }
}